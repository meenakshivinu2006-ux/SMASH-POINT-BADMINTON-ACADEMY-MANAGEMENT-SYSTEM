-- Run this whole file in Supabase > SQL Editor.
create table profiles(id uuid primary key references auth.users on delete cascade, role text not null check (role in ('student','coach','admin')), full_name text not null, phone text, created_at timestamptz default now());
create table students(id uuid primary key default gen_random_uuid(), profile_id uuid unique not null references profiles on delete cascade, name text not null,
  level text not null default 'Beginner' check (level in ('Beginner','Intermediate','Advanced')), style text default 'Allrounder', batch text default 'Evening A', parent_name text, parent_phone text, fee int not null default 2000,
  readiness text not null default 'Fit' check (readiness in ('Fit','Recovery','Injured')), injury_note text,
  sk_footwork int not null default 1 check (sk_footwork between 1 and 5), sk_serve int not null default 1 check (sk_serve between 1 and 5), sk_smashes int not null default 1 check (sk_smashes between 1 and 5), sk_drops int not null default 1 check (sk_drops between 1 and 5),
  racket_model text, racket_tension text, racket_strung date, wins int not null default 0, losses int not null default 0, focus_note text, created_at timestamptz default now());
create table coaches(id uuid primary key default gen_random_uuid(), profile_id uuid unique not null references profiles on delete cascade, name text not null, speciality text, phone text);
create table payments(id uuid primary key default gen_random_uuid(), student_id uuid not null references students on delete cascade, month text not null check (month ~ '^\d{4}-\d{2}$'), amount int not null check (amount > 0), mode text not null check (mode in ('UPI','Cash','Bank transfer')), ref text, proof_path text, paid_on date not null default current_date, receipt_no text unique not null,
  constraint proof_required check ((mode = 'UPI' and proof_path is not null) or (mode in ('Cash','Bank transfer') and ref is not null)));
create unique index payments_txn_unique on payments(ref) where mode = 'Bank transfer';
create table attendance(student_id uuid not null references students on delete cascade, day date not null, present boolean not null default true, primary key(student_id, day));
create table court_bookings(booking_date date not null default current_date, court int check (court between 1 and 4), slot int check (slot between 0 and 5), kind text not null check (kind in ('b','p','c')), primary key(booking_date, court, slot));
create table inventory(item text primary key, qty int not null default 0 check (qty >= 0), min_qty int not null default 5);
insert into inventory values ('Nylon', 0, 8), ('Feather', 0, 6);
create table events(id uuid primary key default gen_random_uuid(), kind text not null check (kind in ('schedule','match')), title text not null, when_text text not null, detail text, student_id uuid references students on delete cascade, created_at timestamptz default now());
create table achievements(id uuid primary key default gen_random_uuid(), student_id uuid not null references students on delete cascade, icon text not null default '🏅', title text not null, created_at timestamptz default now());

create function public.my_role() returns text language sql stable security definer set search_path = public as $$ select role from profiles where id = auth.uid() $$;
create function public.my_student() returns uuid language sql stable security definer set search_path = public as $$ select id from students where profile_id = auth.uid() $$;

-- Coaches may only change coaching fields on a student, never name, fee, contact or batch.
create function public.coach_guard() returns trigger language plpgsql as $$
begin
  if public.my_role() = 'coach' then
    new.profile_id := old.profile_id; new.name := old.name; new.fee := old.fee; new.parent_name := old.parent_name; new.parent_phone := old.parent_phone; new.batch := old.batch;
  end if; return new;
end $$;
create trigger students_coach_guard before update on students for each row execute function public.coach_guard();

alter table profiles enable row level security; alter table students enable row level security; alter table coaches enable row level security; alter table payments enable row level security;
alter table attendance enable row level security; alter table court_bookings enable row level security; alter table inventory enable row level security; alter table events enable row level security; alter table achievements enable row level security;

create policy p_read on profiles for select using (id = auth.uid() or my_role() = 'admin');
create policy s_read on students for select using (my_role() in ('admin','coach') or profile_id = auth.uid());
create policy s_admin on students for all using (my_role() = 'admin') with check (my_role() = 'admin');
create policy s_coach on students for update using (my_role() = 'coach') with check (my_role() = 'coach');
create policy c_read on coaches for select using (my_role() = 'admin' or profile_id = auth.uid());
create policy c_admin on coaches for all using (my_role() = 'admin') with check (my_role() = 'admin');
create policy pay_read on payments for select using (my_role() = 'admin' or student_id = my_student());
create policy pay_admin on payments for all using (my_role() = 'admin') with check (my_role() = 'admin');
create policy a_read on attendance for select using (my_role() in ('admin','coach') or student_id = my_student());
create policy a_staff on attendance for all using (my_role() in ('admin','coach')) with check (my_role() in ('admin','coach'));
create policy cb_read on court_bookings for select using (my_role() in ('admin','coach'));
create policy cb_admin on court_bookings for all using (my_role() = 'admin') with check (my_role() = 'admin');
create policy inv_admin on inventory for all using (my_role() = 'admin') with check (my_role() = 'admin');
create policy ev_read on events for select using (student_id is null or student_id = my_student() or my_role() in ('admin','coach'));
create policy ev_staff on events for all using (my_role() in ('admin','coach')) with check (my_role() in ('admin','coach'));
create policy ac_read on achievements for select using (student_id = my_student() or my_role() in ('admin','coach'));
create policy ac_staff on achievements for all using (my_role() in ('admin','coach')) with check (my_role() in ('admin','coach'));

-- Private bucket for UPI screenshots (admin only).
insert into storage.buckets(id, name, public) values ('payment-proofs', 'payment-proofs', false);
create policy proofs_admin on storage.objects for all using (bucket_id = 'payment-proofs' and public.my_role() = 'admin') with check (bucket_id = 'payment-proofs' and public.my_role() = 'admin');

-- FIRST ADMIN: create a user in Authentication > Users (tick "Auto confirm"), copy its UUID, then run:
-- insert into profiles(id, role, full_name) values ('PASTE-USER-UUID-HERE', 'admin', 'Your Name');
