Smash Point Academy - web app with database (Supabase)
======================================================
Files: index.html (the app), config.js (your keys), supabase/schema.sql, supabase/functions/admin-users/index.ts

SETUP (about 20 minutes, free tier is enough to start)
1. Create a project at supabase.com. Save the database password.
2. SQL Editor > paste supabase/schema.sql > Run. This creates the tables and the row-level security rules
   (players see only their own data, coaches see rosters, only admins see fees and manage accounts).
3. Authentication > Sign In / Providers: turn OFF "Allow new users to sign up". Optionally raise the minimum
   password length. Then Authentication > Users > Add user (tick Auto Confirm) for yourself, copy its UUID and run the
   "FIRST ADMIN" insert at the bottom of schema.sql.
4. Deploy the account function (needs the Supabase CLI): 
     supabase login
     supabase link --project-ref YOUR_PROJECT_REF
     supabase functions deploy admin-users
   Or in the dashboard: Edge Functions > Deploy a new function > name it admin-users > paste index.ts.
5. Open config.js and set SUPABASE_URL and SUPABASE_ANON_KEY (Project Settings > API), plus your UPI ID.
6. Upload the folder to any static host that serves HTTPS (Netlify, Cloudflare Pages, Vercel, GitHub Pages).

DAILY USE
- Admin signs in, opens Students or Coaches, fills the form with an email and a password (Generate makes a strong one),
  and gives the shown details to the account holder. Reset password issues a new one.
- Add schedule and match entries in the Admin dashboard. Add medals with the SQL Editor or Table Editor (achievements table).

SECURITY NOTES
- Never put the service_role key in config.js or index.html. It lives only inside the edge function.
- Sign-in, passwords and sessions are handled by Supabase Auth; access rules are enforced in the database.
- Turn on database backups (Supabase paid plan) before storing real student records, and get parents' consent for storing their details.

PAYMENTS (partial payments and proof)
- Each pending student has "Record payment" (full balance) and "Partial payment" (any amount up to the balance).
- UPI needs a payment screenshot, Cash needs the receipt-book number, Bank transfer needs a transaction ID. The database
  rejects payments without them, and a bank transaction ID cannot be used twice.
- Screenshots go to a private storage bucket and are visible only to admins. Every payment has a printable receipt.
- Already ran an older schema.sql? Run supabase/migration_partial_payments.sql and supabase/migration_critical_fixes.sql once.
