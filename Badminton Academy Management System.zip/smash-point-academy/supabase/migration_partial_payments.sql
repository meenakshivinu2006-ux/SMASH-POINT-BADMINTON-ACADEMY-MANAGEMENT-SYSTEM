-- Only for databases created BEFORE partial payments were added. New installs: schema.sql already includes this.
alter table payments drop constraint if exists payments_student_id_month_key;
alter table payments add column if not exists ref text, add column if not exists proof_path text;
alter table payments drop constraint if exists payments_mode_check;
update payments set ref = coalesce(ref, 'legacy'), mode = 'Bank transfer' where mode not in ('UPI','Cash','Bank transfer');
alter table payments add constraint payments_mode_check check (mode in ('UPI','Cash','Bank transfer'));
alter table payments add constraint payments_amount_check check (amount > 0) not valid;
alter table payments add constraint proof_required check ((mode = 'UPI' and proof_path is not null) or (mode in ('Cash','Bank transfer') and ref is not null)) not valid;  -- old rows are not re-checked
create unique index if not exists payments_txn_unique on payments(ref) where mode = 'Bank transfer';
insert into storage.buckets(id, name, public) values ('payment-proofs', 'payment-proofs', false) on conflict do nothing;
create policy proofs_admin on storage.objects for all using (bucket_id = 'payment-proofs' and public.my_role() = 'admin') with check (bucket_id = 'payment-proofs' and public.my_role() = 'admin');
