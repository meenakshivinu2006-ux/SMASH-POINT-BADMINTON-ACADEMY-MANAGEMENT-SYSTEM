-- Migration: Critical Fixes for Smash Point Academy
-- Run this in Supabase > SQL Editor if you already ran schema.sql previously.

-- 1. Ensure students has created_at for arrears and join-date tracking
alter table students add column if not exists created_at timestamptz default now();

-- 2. Add calendar booking_date to court_bookings so courts aren't statically booked forever
do $$
begin
  if not exists (select 1 from information_schema.columns where table_name='court_bookings' and column_name='booking_date') then
    alter table court_bookings add column booking_date date not null default current_date;
    alter table court_bookings drop constraint if exists court_bookings_pkey;
    alter table court_bookings add primary key (booking_date, court, slot);
  end if;
end $$;

-- 3. Allow coaches and admins to record match events in the events table
drop policy if exists ev_admin on events;
drop policy if exists ev_staff on events;
create policy ev_staff on events for all using (my_role() in ('admin','coach')) with check (my_role() in ('admin','coach'));
