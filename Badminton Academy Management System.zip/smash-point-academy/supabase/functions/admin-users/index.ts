// Admin-only account management. Runs on the server with the service-role key, which never reaches the browser.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type" };
const J = (b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const token = (req.headers.get("Authorization") || "").replace("Bearer ", "");
    const { data: { user } } = await admin.auth.getUser(token);
    if (!user) return J({ error: "Not signed in" }, 401);
    const { data: me } = await admin.from("profiles").select("role").eq("id", user.id).single();
    if (me?.role !== "admin") return J({ error: "Only admins can manage accounts" }, 403);
    const b = await req.json();

    if (b.action === "create") {
      if (!["student", "coach"].includes(b.role)) return J({ error: "Invalid role" }, 400);
      if (!b.email || String(b.password || "").length < 8) return J({ error: "An email and a password of 8+ characters are required" }, 400);
      const { data: u, error } = await admin.auth.admin.createUser({ email: b.email, password: b.password, email_confirm: true });
      if (error) return J({ error: error.message }, 400);
      const id = u.user.id;
      const e1 = (await admin.from("profiles").insert({ id, role: b.role, full_name: b.profile.full_name, phone: b.profile.phone })).error;
      const e2 = e1 ? e1 : (await admin.from(b.role === "student" ? "students" : "coaches").insert({ ...b.record, profile_id: id })).error;
      if (e2) { await admin.auth.admin.deleteUser(id); return J({ error: e2.message }, 400); }
      return J({ ok: true, id });
    }

    const t = b.user_ref?.table;
    if (!["students", "coaches"].includes(t)) return J({ error: "Bad request" }, 400);
    const { data: row } = await admin.from(t).select("profile_id").eq("id", b.user_ref.id).single();
    if (!row) return J({ error: "Account not found" }, 404);

    if (b.action === "reset_password") {
      if (String(b.password || "").length < 8) return J({ error: "Password must be 8+ characters" }, 400);
      const { data: u, error } = await admin.auth.admin.updateUserById(row.profile_id, { password: b.password });
      if (error) return J({ error: error.message }, 400);
      return J({ ok: true, email: u.user.email });
    }
    if (b.action === "delete") {
      const { error } = await admin.auth.admin.deleteUser(row.profile_id);
      if (error) return J({ error: error.message }, 400);
      return J({ ok: true });
    }
    return J({ error: "Unknown action" }, 400);
  } catch (e) { return J({ error: String((e as Error).message || e) }, 500); }
});
