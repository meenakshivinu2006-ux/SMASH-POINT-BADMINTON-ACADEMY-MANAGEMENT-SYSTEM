// Fill these two values from Supabase: Project Settings > API.
// The anon key is meant to be public. NEVER put the service_role key here.
window.APP_CONFIG = {
  SUPABASE_URL: "https://lfkyyvhqtnnrzivggatp.supabase.co",
  SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imxma3l5dmhxdG5ucnppdmdnYXRwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE0NDIxNjgsImV4cCI6MjEwNzAxODE2OH0.iTo8ZIOFaTo7ym4_agHasQqIRPknQ7KzvHjCPEsYEw8",
  ACADEMY: "Smash Point Academy",
  UPI_ID: "yourupi@bank",
  SESSIONS_PER_MONTH: 20
};
